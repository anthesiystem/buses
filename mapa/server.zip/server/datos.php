<?php
$host = 'localhost';
$db = 'seguimientobus';
$user = 'admin';
$pass = 'admin1234';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
  die("Conexión fallida: " . $conn->connect_error);
}

// proteger parámetro
$bus = isset($_GET['bus']) ? $_GET['bus'] : '';

if (empty($bus)) {
    die("Falta parámetro bus");
}

$sql = "SELECT entidad, GROUP_CONCAT(DISTINCT estatus) as estatuses 
        FROM segbus 
        WHERE BUS = ?
        GROUP BY entidad";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $bus);
$stmt->execute();
$result = $stmt->get_result();

$datos = [];

while ($row = $result->fetch_assoc()) {
  $estado = $row['entidad'];
  $estatuses = explode(",", $row['estatuses']);

  if (count($estatuses) === 1) {
    $val = strtolower($estatuses[0]);
    $datos[$estado] = ($val === 'concluido' || $val === 'sin ejecutar') ? $val : 'mixto';
  } else {
    $datos[$estado] = 'mixto';
  }
}

header('Content-Type: application/json');
echo json_encode($datos);
$conn->close();
?>
