<?php
$host = 'localhost';
$db = 'seguimientobus';
$user = 'admin';
$pass = 'admin1234';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
  die("Conexión fallida: " . $conn->connect_error);
}

$estado = $_GET['estado'] ?? '';
$bus = $_GET['bus'] ?? '';

$estado = $conn->real_escape_string($estado);
$bus = $conn->real_escape_string($bus);

// Obtener solo los registros del estado y bus seleccionado
$sql = "SELECT bus, version, estatus, avance 
        FROM segbus 
        WHERE entidad = '$estado' AND bus = '$bus'
        ORDER BY estatus, bus";

$result = $conn->query($sql);

$agrupados = [];
$totalBuses = 0;

while ($row = $result->fetch_assoc()) {
  $estatus = strtoupper($row['estatus']);
  $agrupados[$estatus][] = $row;
  $totalBuses++;
}

echo "<h2>" . strtoupper($estado) . "</h2>";
echo "<p><strong>CANTIDAD DE BUSES:</strong> $totalBuses</p>";

foreach ($agrupados as $estatus => $registros) {
  $count = count($registros);
  echo "<h3>$estatus ($count)</h3>";
  echo "<table border='1' cellspacing='0' cellpadding='4'>
          <thead style='background:#000; color:#fff;'>
            <tr>
              <th>BUS</th>
              <th>VERSION</th>
              <th>ESTATUS</th>
              <th>AVANCE</th>
            </tr>
          </thead>
          <tbody>";
  foreach ($registros as $fila) {
    echo "<tr>
            <td>{$fila['bus']}</td>
            <td>{$fila['version']}</td>
            <td>{$fila['estatus']}</td>
            <td>{$fila['avance']}</td>
          </tr>";
  }
  echo "</tbody></table><br>";
}

$conn->close();
?>
