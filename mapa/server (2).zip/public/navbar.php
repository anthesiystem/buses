<div class="navbar">
    <a href="index.php">Bus Prod</a>
    <a href="vryr.php">VRyR</a>
    <a href="rnl.php">LC</a>
    <a href="rnip.php">RNIP</a>
    <a href="mj.php">MJ</a>
    <a href="cup.php">CUP</a>
    <a href="911.php">911</a>
    <a href="lpr.php">LPR</a>
    <a href="rnae.php">RNAE</a>
    <a href="eo.php">EO</a>
    <a href="vo.php">VO</a>
    <?php if (isset($_SESSION['nivel']) && ($_SESSION['nivel'] == 2 || $_SESSION['nivel'] == 3)): ?>
      <a href="registro.php">Registros</a>
    <?php endif; ?>
    <a href="logout.php">Salir</a>
</div>
