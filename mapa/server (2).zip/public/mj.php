<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>MJ</title>
  <link rel="stylesheet" href="../server/style.css">
</head>
<body>
<?php include 'navbar.php'; ?>

  <div class="contenedor">
    <div id="mapa">
      <?php echo file_get_contents("mapa.svg"); ?>
    </div>
    <div id="info">
      <center><img src="../icons/mj.png" width="30%" height="30%"/>
      <h3>Mandamientos Judiciales</h3>
      <div id="detalle"></div>
    </div>
  </div>

  <script>
    const estadoMap = {
      'MX-AGU': 'Aguascalientes',
      'MX-BCN': 'Baja California',
      'MX-BCS': 'Baja California Sur',
      'MX-CAM': 'Campeche',
      'MX-CHP': 'Chiapas',
      'MX-CHH': 'Chihuahua',
      'MX-CMX': 'Ciudad de México',
      'MX-COA': 'Coahuila',
      'MX-COL': 'Colima',
      'MX-DUR': 'Durango',
      'MX-GUA': 'Guanajuato',
      'MX-GRO': 'Guerrero',
      'MX-HID': 'Hidalgo',
      'MX-JAL': 'Jalisco',
      'MX-MEX': 'México',
      'MX-MIC': 'Michoacán',
      'MX-MOR': 'Morelos',
      'MX-NAY': 'Nayarit',
      'MX-NLE': 'Nuevo León',
      'MX-OAX': 'Oaxaca',
      'MX-PUE': 'Puebla',
      'MX-QUE': 'Querétaro',
      'MX-ROO': 'Quintana Roo',
      'MX-SLP': 'San Luis Potosí',
      'MX-SIN': 'Sinaloa',
      'MX-SON': 'Sonora',
      'MX-TAB': 'Tabasco',
      'MX-TAM': 'Tamaulipas',
      'MX-TLA': 'Tlaxcala',
      'MX-VER': 'Veracruz',
      'MX-YUC': 'Yucatán',
      'MX-ZAC': 'Zacatecas'
    };

    document.addEventListener("DOMContentLoaded", () => {
      const tooltip = document.createElement("div");
      tooltip.id = "tooltip";
      document.body.appendChild(tooltip);

      const busSeleccionado = "MJ (MANDAMIENTOS)";  // se reutiliza fácilmente

    fetch('../server/datos.php?bus=' + encodeURIComponent(busSeleccionado))
      .then(response => response.json())
      .then(data => {
        document.querySelectorAll('path[id^="MX-"]').forEach(path => {
          const clave = path.id;
          const nombreEstado = estadoMap[clave];

            if (!nombreEstado || !(nombreEstado in data)) return;

            const estatus = data[nombreEstado];

            if (estatus === 'concluido') path.style.fill = '#85c03b';
            else if (estatus === 'sin ejecutar') path.style.fill = 'gray';
            else path.style.fill = '#9ebb7a';

            path.addEventListener('mouseenter', (e) => {
              tooltip.textContent = nombreEstado;
              tooltip.style.display = 'block';
            });
            path.addEventListener('mousemove', (e) => {
              tooltip.style.left = (e.pageX + 10) + 'px';
              tooltip.style.top = (e.pageY + 10) + 'px';
            });
            path.addEventListener('mouseleave', () => {
              tooltip.style.display = 'none';
            });
            path.addEventListener('click', () => {
              fetch('../server/detalle.php?estado=' + encodeURIComponent(nombreEstado) + '&bus=' + encodeURIComponent('911 (EMERGENCIAS)'))
                .then(response => response.text())
                .then(html => {
                  document.getElementById('detalle').innerHTML = html;
                });
            });

          });
        });
    });
  </script>
</body>
</html>
