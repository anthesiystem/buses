
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Iniciar Sesión</title>
  <link rel="stylesheet" href="../server/style.css">
  <style>
    body {
      background: #f1f3f7;
      font-family: Arial, sans-serif;
    }
    .login-box {
      width: 300px;
      margin: 100px auto;
      background: white;
      border-radius: 10px;
      padding: 20px;
      text-align: center;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    .login-box img {
      width: 100%;
      border-radius: 10px 10px 0 0;
    }
    input[type="text"], input[type="password"] {
      width: 90%;
      padding: 10px;
      margin: 10px 0;
      border: none;
      border-bottom: 1px solid #ccc;
    }
    .login-box button {
      width: 90%;
      padding: 10px;
      margin-top: 20px;
      background: #c00;
      color: white;
      font-weight: bold;
      border: none;
      border-radius: 20px;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <div class="login-box">
    <img src="bd.png" alt="Login Banner">
    <form action="../server/validar.php" method="post">
      <input type="text" name="usuario" placeholder="Ingresa Usuario" required><br>
      <input type="password" name="password" placeholder="Ingresa Contraseña" required><br>
      <button type="submit">INGRESAR</button>
    </form>
  </div>
</body>
</html>