<?php
session_start();
$host = 'localhost';
$db = 'busmap';
$user = 'admin';
$pass = 'admin1234';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$usuario = $_POST['usuario'];
$password = $_POST['password'];

$usuario = $conn->real_escape_string($usuario);
$password = $conn->real_escape_string($password);

$sql = "SELECT User, Password, Nivel FROM users WHERE User = '$usuario' AND Password = '$password'";
$result = $conn->query($sql);

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();  
    $_SESSION['usuario'] = $row['User'];  
    $_SESSION['nivel'] = $row['Nivel'];



    header("Location: ../public/index.php");
    exit();
} else {
    echo "<script>alert('Usuario o contraseña incorrectos');window.location='../public/login.php';</script>";
}
$conn->close();
?>