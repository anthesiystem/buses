<?php
$host = 'localhost';
$db = 'busmap';
$user = 'admin';
$pass = 'admin1234';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$estado = $_GET['estado'] ?? '';
$bus = $_GET['bus'] ?? '';

$estado = $conn->real_escape_string($estado);
$bus = $conn->real_escape_string($bus);

$sql = "
    SELECT 
        b.Nombre AS bus_nombre,
        r.Version,
        es.Valor AS estatus_nombre,
        r.Avance,
        r.Fecha_Inicio,
        r.Migracion,
        r.Fecha_Creacion
    FROM registro r
    INNER JOIN entidad e ON e.Id = r.Fk_Id_Entidad
    INNER JOIN estatus es ON es.Id = r.Fk_Id_Estatus
    INNER JOIN bus b ON b.Id = r.Fk_Id_Bus
    WHERE e.Nombre = ? AND b.Nombre = ?
    ORDER BY es.Valor, b.Nombre
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $estado, $bus);
$stmt->execute();
$result = $stmt->get_result();

$agrupados = [];
$totalBuses = 0;

while ($row = $result->fetch_assoc()) {
    $estatus = mb_strtoupper($row['estatus_nombre']);
    $agrupados[$estatus][] = $row;
    $totalBuses++;
}

echo "<h2>" . mb_strtoupper($estado) . "</h2>";
echo "<h3><p><strong>CANTIDAD DE BUSES:</strong> $totalBuses</p></h3>";

foreach ($agrupados as $estatus => $registros) {
    $count = count($registros);
    echo "<h4>$estatus ($count)</h4>";
    echo "<div class='table-responsive'>
        <table class='table table-bordered table-striped table-hover align-middle'>
            <thead class='table-dark'>
            <tr>
                <th>BUS</th>
                <th>VERSION</th>
                <th>ESTATUS</th>
                <th>AVANCE</th>
            </tr>
            </thead>
            <tbody>";

    foreach ($registros as $fila) {
        echo "<tr>
                <td>{$fila['bus_nombre']}</td>
                <td>{$fila['Version']}</td>
                <td>{$fila['estatus_nombre']}</td>
                <td>{$fila['Avance']}%</td>
                
              </tr>";
    }
    echo "</tbody></table><br>";
}

$conn->close();
?>
