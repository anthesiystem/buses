<?php
include '../server/auth.php'
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>LPR</title>
  <link rel="stylesheet" href="../server/style.css">
</head>
<body>
<?php include 'navbar.php'; ?>

  <div class="contenedor">
    <div id="mapa">
      <?php echo file_get_contents("mapa.svg"); ?>
    </div>
          <script 
            id="mapaScript"
            src="../server/mapa.js"
            data-bus="LPR(HITS-ALERT)"
            data-color-concluido="#4f5050"
            data-color-sin-ejecutar="gray"
            data-color-otro="#696969">
          </script>

    <div id="info">
      <center><img src="../icons/lpr.png" width="30%" height="30%"/>
      <h3>HITS ALERT</h3>
      <div id="detalle"></div>
    </div>
  </div>
</body>
</html>
