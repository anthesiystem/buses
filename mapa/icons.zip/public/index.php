<?php
include '../server/auth.php'
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>BUS INTEGRACION</title>
  <link rel="stylesheet" href="../server/style.css">
  

</head>
<body>
  <?php include 'navbar.php'; ?>

  <div class="contenedor">
    <div id="mapa">
      <?php echo file_get_contents("mapa.svg"); ?>
    </div>
    <div id="info">
      <center>
        <h2>Información del Estado</h2>
        <div id="detalle"></div>
      </center>
    </div>
  </div>

  <script src="../server/estadoMap.js"></script>
  <script>


    document.addEventListener("DOMContentLoaded", () => {
      const tooltip = document.createElement("div");
      tooltip.id = "tooltip";
      document.body.appendChild(tooltip);

      fetch('../server/dindex.php')
        .then(response => response.json())
        .then(data => {
			console.log("datos obtenidos:", data);
			document.querySelectorAll('path[id^="MX-"]').forEach(path => {
				const clave = path.id;
				const nombreEstado = estadoMap[clave];
				console.log("clave:", clave, "→", nombreEstado);
				if (!nombreEstado || !(nombreEstado in data)) {
					console.log("NO coincide:", nombreEstado);
					return;
				}

            const estatus = data[nombreEstado];
			console.log("pintando", nombreEstado, "estatus", estatus);

            if (estatus === 'concluido') path.style.fill = '#1f9d0b';
            else if (estatus === 'sin ejecutar') path.style.fill = 'gray';
            else path.style.fill = '#8cbe92';

            path.addEventListener('mouseenter', (e) => {
              tooltip.textContent = nombreEstado;
              tooltip.style.display = 'block';
            });
            path.addEventListener('mousemove', (e) => {
              tooltip.style.left = (e.pageX + 10) + 'px';
              tooltip.style.top = (e.pageY + 10) + 'px';
            });
            path.addEventListener('mouseleave', () => {
              tooltip.style.display = 'none';
            });
            path.addEventListener('click', () => {
              fetch('../server/detalle.php?estado=' + encodeURIComponent(nombreEstado))
                .then(response => response.text())
                .then(html => {
                  document.getElementById('detalle').innerHTML = html;
                });
            });
          });
        });
    });
  </script>
</body>
</html>
