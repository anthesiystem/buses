<?php
include '../server/auth.php'
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>LC</title>
  <link rel="stylesheet" href="../server/style.css">
</head>
<body>
<?php include 'navbar.php'; ?>

  <div class="contenedor">
    <div id="mapa">
      <?php echo file_get_contents("mapa.svg"); ?>
    </div>
    		  <script 
            id="mapaScript"
            src="../server/mapa.js"
            data-bus="RNL (LICENCIAS)"
            data-color-concluido="#ffc000"
            data-color-sin-ejecutar="gray"
            data-color-otro="#edd795">
          </script>
    <div id="info">
      <center><img src="../icons/lc.png" width="30%" height="30%"/>
      <h3>Licencias Oficiales</h3>
      <div id="detalle"></div>
    </div>
  </div>

</body>
</html>
