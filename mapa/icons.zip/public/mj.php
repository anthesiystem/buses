<?php
include '../server/auth.php'
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>MJ</title>
  <link rel="stylesheet" href="../server/style.css">
</head>
<body>
<?php include 'navbar.php'; ?>

  <div class="contenedor">
    <div id="mapa">
      <?php echo file_get_contents("mapa.svg"); ?>
    </div>
          <script 
            id="mapaScript"
            src="../server/mapa.js"
            data-bus="MJ (MANDAMIENTOS)"
            data-color-concluido="#85c03b"
            data-color-sin-ejecutar="gray"
            data-color-otro="#9ebb7a">
          </script>
    <div id="info">
      <center><img src="../icons/mj.png" width="30%" height="30%"/>
      <h3>Mandamientos Judiciales</h3>
      <div id="detalle"></div>
    </div>
  </div>
  
</body>
</html>
