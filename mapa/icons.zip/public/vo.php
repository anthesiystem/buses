<?php
include '../server/auth.php'
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>VO</title>
  <link rel="stylesheet" href="../server/style.css">
</head>
<body>
<?php include 'navbar.php'; ?>

  <div class="contenedor">
    <div id="mapa">
      <?php echo file_get_contents("mapa.svg"); ?>
    </div>

    		  <script 
            id="mapaScript"
            src="../server/mapa.js"
            data-bus="VEH(OFICIALES)"
            data-color-concluido="#a30f0b"
            data-color-sin-ejecutar="gray"
            data-color-otro="#884846">
          </script>

    <div id="info">
      <center><img src="../icons/vo.png" width="30%" height="30%"/>
      <h3>Vehiculos Oficiales</h3>
      <div id="detalle"></div>
    </div>
  </div>

</body>
</html>
