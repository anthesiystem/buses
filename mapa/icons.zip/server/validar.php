<?php
ini_set('session.gc_maxlifetime', 3600); // Tiempo de inactividad 1 hora = 3600 seg
session_set_cookie_params(1800);    // Cookie de 30 minutos
session_start();

$host = 'localhost';
$db = 'busmap';
$user = 'admin';
$pass = 'admin1234';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if (isset($_POST['usuario']) && isset($_POST['password'])) {

    $usuario = $_POST['usuario'];
    $password = $_POST['password'];


    // Sentencia preparada para evitar inyección SQL
    $stmt = $conn->prepare("SELECT User, Password, Nivel FROM users WHERE user = ?");
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();

        // Iniciar sesión
        $_SESSION['usuario'] = $row['User'];
        $_SESSION['nivel'] = $row['Nivel'];
        $_SESSION['ultima_actividad'] = time(); // Tiempo actual

        // Guardar en cookies por 30 minutos
        $expira = time() + 1800;
        setcookie("usuario", $row['user'], $expira, "/", "", false, true);
        setcookie("nivel", $row['nivel'], $expira, "/", "", false, true);

        header("Location: ../public/index.php");
        exit();
    } else {
        echo "<script>alert('Usuario o contraseña incorrectos');window.location='../public/login.php';</script>";
    }

    $stmt->close();
} else {
    echo "<script>alert('Usuario o contraseña incorrectos');window.location='../public/login.php';</script>";
}
$conn->close();
?>