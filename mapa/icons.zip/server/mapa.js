console.log("mapa.js cargado");

document.addEventListener("DOMContentLoaded", () => {
    const script = document.getElementById("mapaScript");

    if (!script) {
        console.error("No se encontró el script con id=mapaScript");
        return;
    }

    const busSeleccionado = script.dataset.bus;
    const colorConcluido = script.dataset.colorConcluido;
    const colorSinEjecutar = script.dataset.colorSinEjecutar;
    const colorOtro = script.dataset.colorOtro;

    console.log("busSeleccionado:", busSeleccionado);

    const estadoMap = {
      'MX-AGU': 'Aguascalientes',
      'MX-BCN': 'Baja California',
      'MX-BCS': 'Baja California Sur',
      'MX-CAM': 'Campeche',
      'MX-CHP': 'Chiapas',
      'MX-CHH': 'Chihuahua',
      'MX-CMX': 'Ciudad de México',
      'MX-COA': 'Coahuila',
      'MX-COL': 'Colima',
      'MX-DUR': 'Durango',
      'MX-GUA': 'Guanajuato',
      'MX-GRO': 'Guerrero',
      'MX-HID': 'Hidalgo',
      'MX-JAL': 'Jalisco',
      'MX-MEX': 'Estado de México',
      'MX-MIC': 'Michoacán',
      'MX-MOR': 'Morelos',
      'MX-NAY': 'Nayarit',
      'MX-NLE': 'Nuevo León',
      'MX-OAX': 'Oaxaca',
      'MX-PUE': 'Puebla',
      'MX-QUE': 'Querétaro',
      'MX-ROO': 'Quintana Roo',
      'MX-SLP': 'San Luis Potosí',
      'MX-SIN': 'Sinaloa',
      'MX-SON': 'Sonora',
      'MX-TAB': 'Tabasco',
      'MX-TAM': 'Tamaulipas',
      'MX-TLA': 'Tlaxcala',
      'MX-VER': 'Veracruz',
      'MX-YUC': 'Yucatán',
      'MX-ZAC': 'Zacatecas'
    };

    // crear tooltip
    const tooltip = document.createElement("div");
    tooltip.id = "tooltip";
    document.body.appendChild(tooltip);

    // pedir datos al servidor
    fetch('../server/datos.php?bus=' + encodeURIComponent(busSeleccionado))
      .then(response => response.json())
      .then(data => {
        console.log("datos obtenidos:", data);
        document.querySelectorAll('path[id^="MX-"]').forEach(path => {
          const clave = path.id;
          const nombreEstado = estadoMap[clave];

          if (!nombreEstado || !(nombreEstado in data)) return;

          const estatus = data[nombreEstado];

          if (estatus === 'concluido') {
            path.style.fill = colorConcluido;
          }
          else if (estatus === 'sin ejecutar') {
            path.style.fill = colorSinEjecutar;
          }
          else {
            path.style.fill = colorOtro;
          }

          path.addEventListener('mouseenter', (e) => {
            tooltip.textContent = nombreEstado;
            tooltip.style.display = 'block';
          });
          path.addEventListener('mousemove', (e) => {
            tooltip.style.left = (e.pageX + 10) + 'px';
            tooltip.style.top = (e.pageY + 10) + 'px';
          });
          path.addEventListener('mouseleave', () => {
            tooltip.style.display = 'none';
          });
          path.addEventListener('click', () => {
            fetch('../server/busvista.php?estado=' + encodeURIComponent(nombreEstado) + '&bus=' + encodeURIComponent(busSeleccionado))
              .then(response => response.text())
              .then(html => {
                document.getElementById('detalle').innerHTML = html;
              });
          });
        });
      });
});
