<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
echo "<!-- SESION usuario=" . ($_SESSION['usuario'] ?? 'no hay') . " -->";


require_once __DIR__ . '/config.php';
// NO session_start aquí

$usuario_actual = isset($_SESSION['usuario']) ? $_SESSION['usuario'] : 'sistema';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fk_tecnologia = $_POST['fk_tecnologia'];
    $fk_dependencia = $_POST['fk_dependencia'];
    $fk_entidad = $_POST['fk_entidad'];
    $fk_bus = $_POST['fk_bus'];
    $fk_estatus = $_POST['fk_estatus'];
    $avance = $_POST['avance'];
    $version = $_POST['version'];
    $fecha_inicio = $_POST['fecha_inicio'];
    $migracion = $_POST['migracion'];
    $id = isset($_POST['id']) ? $_POST['id'] : null;

    $fecha_modificacion = date('Y-m-d H:i:s');

    if (isset($_POST['agregar'])) {
        $stmt = $pdo->prepare("
            INSERT INTO registro 
            (Fk_Id_Tecnologia, Fk_Id_Dependencia, Fk_Id_Entidad, Fk_Id_Bus, Fk_Id_Estatus, Avance, Version, Fecha_Inicio, Migracion, Fecha_Modificacion, Ultimo_Usuario)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $fk_tecnologia, $fk_dependencia, $fk_entidad, $fk_bus, $fk_estatus,
            $avance, $version, $fecha_inicio, $migracion,
            $fecha_modificacion, $usuario_actual
        ]);
    }

    if (isset($_POST['actualizar']) && $id) {
        $stmt = $pdo->prepare("
            UPDATE registro SET
                Fk_Id_Tecnologia=?, Fk_Id_Dependencia=?, Fk_Id_Entidad=?, Fk_Id_Bus=?, Fk_Id_Estatus=?, Avance=?,
                Version=?, Fecha_Inicio=?, Migracion=?, Fecha_Modificacion=?, Ultimo_Usuario=?
            WHERE Id=?
        ");
        $stmt->execute([
            $fk_tecnologia, $fk_dependencia, $fk_entidad, $fk_bus, $fk_estatus,
            $avance, $version, $fecha_inicio, $migracion,
            $fecha_modificacion, $usuario_actual,
            $id
        ]);
    }

    if (isset($_POST['eliminar']) && $id) {
        $stmt = $pdo->prepare("DELETE FROM registro WHERE Id=?");
        $stmt->execute([$id]);
    }

    header("Location: ../public/registro.php");
    exit;
}
?>
