
<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Tablero</title>
  <link rel="stylesheet" href="../server/style.css">

  <style>
    /* Anula el estilo de #info solo en esta página */
    #info {
      width: auto !important;
      padding: 0 !important;
      border: none !important;
    }

    #info-tablero {
      width: 100%;
      padding: 0;
      margin: 0 auto;
    }

    #info-tablero h1 {
      text-align: center;
      font-size: 28px;
      margin-bottom: 30px;
      text-transform: uppercase;
    }

    /* Aislar visualmente el tablero */
    .zona-tablero * {
      all: unset;
      box-sizing: border-box;
    }

    .zona-tablero {
      display: flex;
      justify-content: center;
      width: 100%;
      margin-top: 40px;
      font-family: Arial, sans-serif;
    }

    .contenedor-dashboard {
      display: flex;
      justify-content: center;
      align-items: flex-start;
      gap: 60px;
      padding: 30px;
      max-width: 1200px;
      width: 100%;
      margin: 0 auto;
    }

    .panel-produccion {
      min-width: 250px;
      background-color: #f1f1f1;
      padding: 30px 20px;
      text-align: center;
      border-radius: 12px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    .panel-produccion h1 {
      font-size: 28px;
      margin-bottom: 20px;
      font-weight: bold;
      text-align: center;
    }

    .panel-produccion p {
      font-size: 24px;
      margin: 0;
    }

    .cantidad-total {
  display: block;
  font-size: 86px !important;
  font-weight: bold !important;
  color: #222;
  margin: 0;
  text-align: center;
}

    .tabla-articulos {
      display: grid;
      grid-template-columns: repeat(5, 1fr);
      gap: 30px;
      justify-items: center;
    }

    .articulo img {
      width: 70px;
      height: 70px;
    }

    .nombre-bus {
      font-size: 16px;
      margin-top: 10px;
      color: #555;
    }

    .cantidad-bus {
      font-size: 32px;
      font-weight: bold;
      color: #222;
      margin-top: 8px;
    }

    .articulo {
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }
  </style>
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="contenedor">
  <div id="info-tablero">
    <h1>DETALLE DE BUSES IMPLEMENTADOS</h1>

    <?php
    // Conexión a la base de datos
    $conexion = new mysqli("localhost", "admin", "admin1234", "busmap");
    if ($conexion->connect_error) {
        die("Error de conexión: " . $conexion->connect_error);
    }

    // Consulta agrupada por categoría
    /*$sql = "
    SELECT
      CASE
        WHEN BUS LIKE '911%' THEN '911'
        WHEN BUS LIKE 'CUP%' THEN 'cup'
        WHEN BUS LIKE 'EO%' THEN 'eo'
        WHEN BUS LIKE 'LC%' THEN 'lc'
        WHEN BUS LIKE 'LPR%' THEN 'lpr'
        WHEN BUS LIKE 'MJ%' THEN 'mj'
        WHEN BUS LIKE 'RPAE%' OR BUS LIKE 'RNAE%' THEN 'rnae'
        WHEN BUS LIKE 'RNIP%' THEN 'rnip'
        WHEN BUS LIKE 'VO%' THEN 'vo'
        WHEN BUS LIKE 'VRYR%' THEN 'vryr'
        ELSE 'otros'
      END AS categoria,
      COUNT(*) AS total
    FROM segbus
    GROUP BY categoria;
    ";*/

    $sql = "SELECT
            CASE
              WHEN b.Nombre LIKE 'RNAE%ARMAMENTO%' THEN 'rnae'
              WHEN b.Nombre LIKE 'RNAE%EQUIPO%' THEN 'eo'
              WHEN b.Nombre LIKE '911%' THEN '911'
              WHEN b.Nombre LIKE 'CUP%' THEN 'cup'
              WHEN b.Nombre LIKE 'RNL%' THEN 'lc'
              WHEN b.Nombre LIKE 'LPR%' THEN 'lpr'
              WHEN b.Nombre LIKE 'MJ%' THEN 'mj'
              WHEN b.Nombre LIKE 'RNIP%' THEN 'rnip'
              WHEN b.Nombre LIKE 'VEH%' THEN 'vo'
              WHEN b.Nombre LIKE 'VRyR%' THEN 'vryr'
              ELSE 'otros'
            END AS categoria,
            COUNT(*) AS total
            FROM registro r
            INNER JOIN bus b ON r.Fk_Id_Bus = b.Id
            WHERE 
              b.Nombre IS NOT NULL 
              AND b.Nombre != '' 
              AND b.Nombre NOT LIKE '%VACIA%'
            GROUP BY categoria
            HAVING categoria != 'otros'
            ORDER BY categoria;";


    $sql_TOTAL = "
      SELECT COUNT(Fk_Id_Bus) AS total
      FROM registro
      WHERE Fk_Id_Bus != 1
      AND Fk_Id_Bus NOT BETWEEN 3 AND 5;
    ";
    $resultado_total = $conexion->query($sql_TOTAL);
    $total = 0;

    if ($resultado_total && $row = $resultado_total->fetch_assoc()) {
      $total = $row['total'];
    }


    $resultado = $conexion->query($sql);

    $categorias = ['vryr', 'lc', 'rnip', 'mj', 'cup', '911', 'lpr', 'rnae', 'eo', 'vo'];
    $datos = array_fill_keys($categorias, 0);
    $totalGeneral = 0;

    while ($fila = $resultado->fetch_assoc()) {
        $cat = strtolower($fila['categoria']);
        $count = intval($fila['total']);
        if (array_key_exists($cat, $datos)) {
            $datos[$cat] = $count;
        }
        $totalGeneral += $count;
    }
    

    $conexion->close();
    ?>

    <!-- Tablero separado del resto -->
    <section class="zona-tablero">
      <div class="contenedor-dashboard">

        <!-- Panel izquierdo -->
        <div class="panel-produccion">
          <h1><strong>PRODUCCIÓN</strong></h1>
          <p class="cantidad-total"><?php echo $total; ?></p>
        </div>

        <!-- Panel derecho -->
        <div class="tabla-articulos">
          <?php
          foreach ($categorias as $cat) {
              $nombre = strtoupper($cat);
              $cantidad = $datos[$cat];
              echo "
              <div class='articulo'>
                <img src='../icons/{$cat}.png' alt='{$nombre}'>
                <h4 class='nombre-bus'>{$nombre}</h4>
                <p class='cantidad-bus'>{$cantidad}</p>
              </div>";
          }
          ?>
        </div>

      </div>
    </section>

  </div>
</div>

</body>
</html>

