<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// tiempo máximo en segundos
$timeout = 15 * 60; // 15 minutos

// verificar tiempo de actividad
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > $timeout)) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit;
}
$_SESSION['LAST_ACTIVITY'] = time();

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>CU</title>
  <link rel="stylesheet" href="../server/style.css">
</head>
<body>
<?php include 'navbar.php'; ?>

  <div class="contenedor">
    <div id="mapa">
      <?php echo file_get_contents("mapa.svg"); ?>
    </div>
    <div id="info">
      <center><img src="../icons/cup.png" width="30%" height="30%"/>
      <h3>Certificado Unico Policial</h3>
      <div id="detalle"></div>
    </div>
  </div>

  <script src="../server/estadoMap.js"></script>
  <script>
    document.addEventListener("DOMContentLoaded", () => {
      const tooltip = document.createElement("div");
      tooltip.id = "tooltip";
      document.body.appendChild(tooltip);

      const busSeleccionado = "CUP (CERTIFICADO)";  // se reutiliza fácilmente

    fetch('../server/datos.php?bus=' + encodeURIComponent(busSeleccionado))
      .then(response => response.json())
      .then(data => {
        document.querySelectorAll('path[id^="MX-"]').forEach(path => {
          const clave = path.id;
          const nombreEstado = estadoMap[clave];
            if (!nombreEstado || !(nombreEstado in data)) return;

            const estatus = data[nombreEstado];

            if (estatus === 'concluido') path.style.fill = '#0c99b0';
            else if (estatus === 'sin ejecutar') path.style.fill = 'gray';
            else path.style.fill = '#527d84';

            path.addEventListener('mouseenter', (e) => {
              tooltip.textContent = nombreEstado;
              tooltip.style.display = 'block';
            });
            path.addEventListener('mousemove', (e) => {
              tooltip.style.left = (e.pageX + 10) + 'px';
              tooltip.style.top = (e.pageY + 10) + 'px';
            });
            path.addEventListener('mouseleave', () => {
              tooltip.style.display = 'none';
            });
            path.addEventListener('click', () => {
            fetch('../server/busvista.php?estado=' + encodeURIComponent(nombreEstado) + '&bus=' + encodeURIComponent(busSeleccionado))
              .then(response => response.text())
              .then(html => {
                document.getElementById('detalle').innerHTML = html;
              });
          });

          });
        });
    });
  </script>
</body>
</html>
