<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>911</title>
  <link rel="stylesheet" href="../server/style.css">
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="contenedor">
  <div id="mapa">
    <?php echo file_get_contents("mapa.svg"); ?>
  </div>
  <div id="info">
    <center>
      <img src="../icons/911.png" width="30%" height="30%"/>
      <h3>Centro de Atención Telefónica</h3>
      <div id="detalle"></div>
    </center>
  </div>
</div>


<!--<script src="../server/estadoMap.js"></script> -->
<!-- Catalogo de estados para poder pintar -->
 
<script 
  src="../server/mapa.js"
  data-bus="911 (EMERGENCIAS)"
  data-color-concluido="#da4839"
  data-color-sin-ejecutar="gray"
  data-color-otro="#85544f">
</script>

<!-- <script>-->
  document.addEventListener("DOMContentLoaded", () => {
    const tooltip = document.createElement("div");
    tooltip.id = "tooltip";
    document.body.appendChild(tooltip);

    const busSeleccionado = "911 (EMERGENCIAS)"; 

    fetch('../server/datos.php?bus=' + encodeURIComponent(busSeleccionado))
      .then(response => response.json())
      .then(data => {
        document.querySelectorAll('path[id^="MX-"]').forEach(path => {
          const clave = path.id;
          const nombreEstado = estadoMap[clave];

          if (!nombreEstado || !(nombreEstado in data)) return;

          const estatus = data[nombreEstado];

          if (estatus === 'concluido') path.style.fill = '#da4839';
          else if (estatus === 'sin ejecutar') path.style.fill = 'gray';
          else path.style.fill = '#85544f';

          path.addEventListener('mouseenter', (e) => {
            tooltip.textContent = nombreEstado;
            tooltip.style.display = 'block';
          });
          path.addEventListener('mousemove', (e) => {
            tooltip.style.left = (e.pageX + 10) + 'px';
            tooltip.style.top = (e.pageY + 10) + 'px';
          });
          path.addEventListener('mouseleave', () => {
            tooltip.style.display = 'none';
          });
          path.addEventListener('click', () => {
            fetch('../server/busvista.php?estado=' + encodeURIComponent(nombreEstado) + '&bus=' + encodeURIComponent(busSeleccionado))
              .then(response => response.text())
              .then(html => {
                document.getElementById('detalle').innerHTML = html;
              });
          });
        });
      });
  });
</script>
</body>
</html>
